<?php
define('SMTP_HOST', 'mail.elaico.ir');
define('SMTP_PORT', 465);
define('SMTP_ENCRYPTION', 'ssl');
define('SMTP_USERNAME', 'noreply@elaico.ir');
define('SMTP_PASSWORD', 'sSv.normandysr2@943A47#GTFOt._');
define('SMTP_FROM_NAME', 'Elaico Support');
define('SMTP_FROM_EMAIL', 'noreply@elaico.ir');