<?php /* head.php */ ?>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="/ticketing-system/assets/css/style.css">
<script src="/ticketing-system/assets/js/theme.js" defer></script> 